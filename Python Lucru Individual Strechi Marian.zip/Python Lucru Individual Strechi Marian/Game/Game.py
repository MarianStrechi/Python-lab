import pygame
import sys
import random

pygame.init()
WIDTH, HEIGHT = 800, 600
background_img = pygame.transform.scale(pygame.image.load("background.png"), (WIDTH, HEIGHT))
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sleepy Ghost")
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 0, 0)

player_imgs = [
    pygame.transform.scale(pygame.image.load("player.png"), (80, 80)),
    pygame.transform.scale(pygame.image.load("player2.png"), (80, 80))
]
player_invuln_imgs = [
    pygame.transform.scale(pygame.image.load("player_ability.png"), (150, 150)),
    pygame.transform.scale(pygame.image.load("player_ability2.png"), (150, 150))
]
player_frame = 0
player_img = player_imgs[player_frame]
player_rect = player_img.get_rect(midbottom=(WIDTH // 2, HEIGHT - 110))
player_vel_y = 0
on_ground = True
player_speed = 5
player_hp = 100
ammo = 5
reloading = False
reload_time = 1500
last_reload_time = 0
facing_right = True

invulnerable = False
invuln_start_time = 0
invuln_duration = 15000
invuln_cooldown = 45000
last_invuln_time = -invuln_cooldown

bullet_img = pygame.image.load("bullet.png")
bullets = []
bullet_speed = 10

class Bullet:
    def __init__(self, x, y, direction):
        self.rect = bullet_img.get_rect(center=(x, y))
        self.direction = direction

    def update(self):
        self.rect.x += self.direction * bullet_speed

    def draw(self, surface):
        surface.blit(bullet_img, self.rect)

score = 0

class Enemy:
    def __init__(self, from_left):
        self.original_images = [
            pygame.image.load("enemy_1.png"),
            pygame.image.load("enemy_2.png")
        ]
        self.original_images = [pygame.transform.scale(img, (60, 60)) for img in self.original_images]
        self.from_left = from_left
        if from_left:
            self.images = [pygame.transform.flip(img, True, False) for img in self.original_images]
        else:
            self.images = self.original_images
        self.current_image = 0
        y_pos = HEIGHT - 120 if not from_left else HEIGHT - 140
        if from_left:
            self.rect = self.images[0].get_rect(midright=(0, y_pos))
        else:
            self.rect = self.images[0].get_rect(midleft=(WIDTH, y_pos))
        self.animation_timer = 0
        self.animation_speed = 200

    def update(self, dt):
        self.rect.x += 3 if self.from_left else -3
        self.animation_timer += dt
        if self.animation_timer >= self.animation_speed:
            self.current_image = (self.current_image + 1) % len(self.images)
            self.animation_timer = 0

    def draw(self, surface):
        surface.blit(self.images[self.current_image], self.rect)

    def get_hitbox(self):
        return pygame.Rect(self.rect.x + 10, self.rect.y + 10, self.rect.width - 20, self.rect.height - 20)

enemies = []

spawn_delay = 2000
max_enemies = 6
enemy_spawn_timer = pygame.USEREVENT + 1
pygame.time.set_timer(enemy_spawn_timer, spawn_delay)

font = pygame.font.SysFont(None, 30)
game_over = False

def reset_game():
    global player_hp, ammo, bullets, enemies, player_rect, game_over, reloading, score, spawn_delay, facing_right, player_img, invulnerable, last_invuln_time
    player_hp = 100
    ammo = 5
    bullets.clear()
    enemies.clear()
    player_rect.midbottom = (WIDTH // 2, HEIGHT - 110)
    game_over = False
    reloading = False
    score = 0
    spawn_delay = 2000
    facing_right = True
    player_img = player_imgs[0]
    invulnerable = False
    last_invuln_time = -invuln_cooldown
    pygame.time.set_timer(enemy_spawn_timer, spawn_delay)

while True:
    dt = clock.tick(60)
    screen.blit(background_img, (0, 0))
    keys = pygame.key.get_pressed()

    if not game_over:
        if keys[pygame.K_a]:
            player_rect.x -= player_speed
            if facing_right:
                facing_right = False
                player_img = pygame.transform.flip(player_img, True, False)
        if keys[pygame.K_d]:
            player_rect.x += player_speed
            if not facing_right:
                facing_right = True
                player_img = pygame.transform.flip(player_img, True, False)

        # Wrap-around pentru player
        if player_rect.right < 0:
            player_rect.left = WIDTH
        elif player_rect.left > WIDTH:
            player_rect.right = 0

        if keys[pygame.K_SPACE] and on_ground:
            player_vel_y = -15
            on_ground = False

        player_vel_y += 1
        player_rect.y += player_vel_y
        if player_rect.bottom >= HEIGHT - 110:
            player_rect.bottom = HEIGHT - 110
            on_ground = True

        if pygame.mouse.get_pressed()[0] and ammo > 0 and not reloading:
            bullet = Bullet(player_rect.right if facing_right else player_rect.left, player_rect.centery, 1 if facing_right else -1)
            bullets.append(bullet)
            ammo -= 1
            pygame.time.delay(150)

        if (ammo <= 0 or keys[pygame.K_r]) and not reloading:
            reloading = True
            last_reload_time = pygame.time.get_ticks()

        if reloading and pygame.time.get_ticks() - last_reload_time >= reload_time:
            ammo = 5
            reloading = False

        if keys[pygame.K_p] and pygame.time.get_ticks() - last_invuln_time >= invuln_cooldown:
            invulnerable = True
            invuln_start_time = pygame.time.get_ticks()
            last_invuln_time = invuln_start_time

        if invulnerable and pygame.time.get_ticks() - invuln_start_time >= invuln_duration:
            invulnerable = False

        for bullet in bullets[:]:
            bullet.update()
            if bullet.rect.right < 0 or bullet.rect.left > WIDTH:
                bullets.remove(bullet)

        for bullet in bullets[:]:
            for enemy in enemies[:]:
                if bullet.rect.colliderect(enemy.get_hitbox()):
                    bullets.remove(bullet)
                    enemies.remove(enemy)
                    score += 1
                    if score % 5 == 0 and spawn_delay > 600:
                        spawn_delay -= 150
                        pygame.time.set_timer(enemy_spawn_timer, spawn_delay)
                    break

        player_hitbox = pygame.Rect(player_rect.x + 10, player_rect.y + 10, player_rect.width - 20, player_rect.height - 20)

        enemies.sort(key=lambda e: e.from_left)

        for enemy in enemies[:]:
            enemy.update(dt)
            if enemy.get_hitbox().colliderect(player_hitbox):
                if not invulnerable:
                    player_hp -= 25
                enemies.remove(enemy)
                if player_hp <= 0:
                    game_over = True
            elif enemy.rect.right < 0 or enemy.rect.left > WIDTH:
                enemies.remove(enemy)

        # Control animatie
        if invulnerable:
            player_img = player_invuln_imgs[player_frame // 20 % len(player_invuln_imgs)]
        else:
            player_img = player_imgs[player_frame // 20 % len(player_imgs)]
        player_frame = (player_frame + 1) % 60
        if not facing_right:
            player_img = pygame.transform.flip(player_img, True, False)

        screen.blit(player_img, player_rect)
        for bullet in bullets:
            bullet.draw(screen)
        for enemy in enemies:
            enemy.draw(screen)

        screen.blit(font.render(f'HP: {player_hp}', True, WHITE), (10, 10))
        screen.blit(font.render(f'Ammo: {ammo}', True, WHITE), (10, 40))
        screen.blit(font.render(f'Score: {score}', True, WHITE), (10, 70))
        if reloading:
            screen.blit(font.render("Recharging...", True, RED), (WIDTH // 2 - 70, HEIGHT // 2))

        if invulnerable:
            remaining = max(0, (invuln_duration - (pygame.time.get_ticks() - invuln_start_time)) // 1000)
            screen.blit(font.render(f'Invulnerability: {remaining}s', True, RED), (10, 100))
        else:
            cooldown_remaining = max(0, (invuln_cooldown - (pygame.time.get_ticks() - last_invuln_time)) // 1000)
            screen.blit(font.render("[P] Ability: Invulnerability", True, WHITE), (WIDTH - 280, 10))
            screen.blit(font.render(f'Cooldown: {cooldown_remaining}s', True, RED), (WIDTH - 200, 40))

    else:
        screen.blit(font.render("You Lose. Press R to retry", True, RED), (WIDTH // 2 - 120, HEIGHT // 2))
        if keys[pygame.K_r]:
            reset_game()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == enemy_spawn_timer and not game_over:
            if len(enemies) < max_enemies:
                enemies.append(Enemy(from_left=random.choice([True, False])))

    pygame.display.flip()